Thanks for purchasing from us - Special Edition, really appreciate it! [https://discord.gg/NCHub]
It is important to us that you maintain the security of the files as much as possible and that you don't give access to programmers that you don't trust! 
In the end it's your money, we're just warning you about this.

Our discord - Discord.gg/NCHub
Youtube - https://www.youtube.com/@nchub

If you have a problem, errors, or anything else we can help you with, we're here for you.
If you didn't purchase the files together with the installation and you encountered something, we will be happy to help you as well.

Thank you again for the purchase, good luck and we hope you will also make a new record of players!
Don't forget - https://discord.gg/NCHub will be always for you!